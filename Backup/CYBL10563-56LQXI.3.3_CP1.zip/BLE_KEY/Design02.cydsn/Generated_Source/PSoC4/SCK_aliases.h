/*******************************************************************************
* File Name: SCK.h  
* Version 2.10
*
* Description:
*  This file contains the Alias definitions for Per-Pin APIs in cypins.h. 
*  Information on using these APIs can be found in the System Reference Guide.
*
* Note:
*
********************************************************************************
* Copyright 2008-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_PINS_SCK_ALIASES_H) /* Pins SCK_ALIASES_H */
#define CY_PINS_SCK_ALIASES_H

#include "cytypes.h"
#include "cyfitter.h"
#include "cypins.h"


/***************************************
*              Constants        
***************************************/
#define SCK_0		(SCK__0__PC)
#define SCK_0_PS		(SCK__0__PS)
#define SCK_0_PC		(SCK__0__PC)
#define SCK_0_DR		(SCK__0__DR)
#define SCK_0_SHIFT	(SCK__0__SHIFT)


#endif /* End Pins SCK_ALIASES_H */


/* [] END OF FILE */

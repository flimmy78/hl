/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "app_protocol.h"
#include "app_ble.h"
#include "app_uart.h"
#include "app_Com.h"
#include <string.h>
#include <stdlib.h>
#include "Rc4.h"

uint8 packetTX[20];
uint8 packetTXStep = 0;
uint8 recv_buff[40];
uint8 AppKey[8];


/***********************************************
* 函数名：void SendNotification(void)
* 描述  ：蓝牙发送函数
***********************************************/
void SendNotification(void)
{
    /* Create a new notification packet */
    CYBLE_GATTS_HANDLE_VALUE_NTF_T notificationPacket;
    notificationPacket.attrHandle = CYBLE_CUSTOM_SERVICE_RX_FROM_APP_CHAR_HANDLE;
    notificationPacket.value.val = packetTX;   
    notificationPacket.value.len = 20;
    /* Report data to BLE component */
    CyBle_GattsNotification(cyBle_connHandle, &notificationPacket);
 
}

/***********************************************
* 函数名：void Send_LockInfo(void)
* 描述  ：发送锁设备信息
***********************************************/
void Send_LockInfo(void)
{
    uint8 i;
    uint16 crc;
    uint16 data_rand;
    memset(packetTX,0x00,sizeof(packetTX));
    packetTX[0] = 0x23;         //命令字
    packetTX[1] = 0;            //包号
    packetTX[2] = 15;           //长度
    
    for(i=0; i<4; i++)      //生成LOCKKEY
    {
        data_rand = rand(); 
        Lock_Info.LockKey[i*2 + 0] = data_rand / 256;
        Lock_Info.LockKey[i*2 + 1] = data_rand % 256; 
    }    
    memcpy(packetTX + 3, Lock_Info.DeviceID,15);
    rc4_encrypt(System_Config.ManageKey,MKEY_LEN,packetTX + 10,8);  //对随机密钥加密
    crc = comCalCRC16(packetTX,18);
    packetTX[18] = crc / 256;
    packetTX[19] = crc % 256; 
    
    SendNotification();
}

/***********************************************
* 函数名：void Back_Massage_Minwen(uint8 cmd,uint8 data)
* 描述  ：返回信息-明文
***********************************************/
void Back_Massage_Minwen(uint8 cmd,uint8 data)
{
    uint16 crc;
    memset(packetTX,0x00,sizeof(packetTX));
    packetTX[0] = cmd;          //命令字
    packetTX[1] = 0;            //包号
    packetTX[2] = 1;            //长度
    packetTX[3] = data;         //结果
    
    crc = comCalCRC16(packetTX,4);
    packetTX[4] = crc / 256;
    packetTX[5] = crc % 256;   
    SendNotification();
}


/***********************************************
* 函数名：void Send_Battery_Voltage(void)
* 描述  ：发送钥匙电压
***********************************************/
void Send_Battery_Voltage(void)
{
    uint16 vol = 3900;      //电池电压需采样计算
    uint16 crc;
    vol = Get_Adc();
    memset(packetTX,0x00,20);
    packetTX[0] = GET_BATTERY_VOLTAGE;
    packetTX[1] = 0;
    packetTX[2] = 2;
    packetTX[3] = vol/256;
    packetTX[4] = vol%256;
    crc = comCalCRC16(packetTX,5);
    packetTX[5] = crc / 256;
    packetTX[6] = crc % 256;  
    SendNotification();
}




/***********************************************
* 函数名：void Send_Factory_Info(void)
* 描述  ：发送钥匙出厂信息
***********************************************/
void Send_Factory_Info(void)
{
    uint16 crc;
    memset(packetTX,0x00,20);
    
    packetTX[0] = REQUEST_FACTORY_INFO;
    packetTX[1] = 0;
    packetTX[2] = 13;
    packetTX[3] = BLE_NORMAL_KEY;
    memcpy(packetTX + 4, System_Config.DeviceID,4);

    packetTX[8] = Ver_H;
    packetTX[9] = Ver_L;
    packetTX[10] = Hw_Ver_H;
    packetTX[11] = Hw_Ver_L;   
    
    packetTX[12] = 1;
    
    packetTX[13] = FACTORY_YEAR;
    packetTX[14] = FACTORY_MONTH;
    packetTX[15] = FACTORY_DAY;
    
    crc = comCalCRC16(packetTX,16);
    packetTX[16] = crc / 256;
    packetTX[17] = crc % 256;  
    SendNotification();
}


/***********************************************
* 函数名：void Back_Massage_Minwen(uint8 cmd,uint8 data)
* 描述  ：分包应答
***********************************************/
void Back_subpackage(uint8 cmd,uint8 pk_num)
{
    uint16 crc;
    memset(packetTX,0x00,sizeof(packetTX));
    packetTX[0] = cmd;
    packetTX[1] = pk_num;           //包号
    packetTX[2] = 0;                //命令字    

    crc = comCalCRC16(packetTX,3);
    packetTX[3] = crc / 256;
    packetTX[4] = crc % 256;   
    SendNotification();
}


/***********************************************
* 函数名：void ReceiveBleCmd(void)
* 描述  ：处理蓝牙接收指令
***********************************************/
void ReceiveBleCmd(void)
{
    uint8 cmd,pkg_num;
    uint16 data_crc,check_crc;
    uint8 data_length = 0;
    
    if(packetRXFlag)
    {
        packetRXFlag=0;         
        
        cmd = packetRX[0];          //命令字
        pkg_num = packetRX[1];      //包号
        data_length = packetRX[2];  //数据长度
        data_crc = comCalCRC16(packetRX,data_length + 3);
        check_crc = packetRX[data_length +3]*256 + packetRX[data_length +4];
        if(data_crc == check_crc)       //校验正确
        {
            switch(cmd)
            {                                                  
                case OPEN_LOCK_CMD:             //开锁
                    if(data_length == 15)
                    {
                        rc4_encrypt(Lock_Info.LockKey,KEY_LEN,packetRX + 3,15);
                        Send_Com(packetRX,data_length + 3);
                        Send_Com(Lock_Info.LockKey,8);
                        data_crc = comCalCRC16(packetRX,16);
                        check_crc = packetRX[16]*256 + packetRX[17];
                        if(data_crc == check_crc) 
                        {
                            Com_Array.Tx_State = RE_CHECKCODE;    
                        }
                    }
                    break;                                         
                
                case GET_BATTERY_VOLTAGE:       //读取钥匙电压
                    if(data_length == 0)
                    {
                        Send_Battery_Voltage();
                    }
                    break;
                
                case SET_KEY_ID:                //设置钥匙ID
                    if(data_length == 4)
                    {
                        memcpy(System_Config.DeviceID,packetRX + 3,4);
                        System_Config.IDChangeFlag = 1;
                        System_Config.sum = CRC_Sum((uint8 *)&System_Config,sizeof(System_Config)-1);
                        Write_Flash((uint8 *)&System_Config,sizeof(System_Config));
                        Back_Massage_Minwen(SET_KEY_ID,PRO_SUCCESS);
                    }                    
                    break;
                    
                case REQUEST_FACTORY_INFO:      //回复出厂信息
                    if(data_length == 4)
                    {
                        Send_Factory_Info();             
                    }
                    break;
                    
                case SET_LOCK_ID:               //设置锁设备号
                    if(data_length == 4)
                    {
                        memcpy(Lock_Info.DeviceID,packetRX + 3,4);
                        Set_Lock_ID();
                        Back_Massage_Minwen(SET_LOCK_ID,PRO_SUCCESS);
                        
                    }
                    break;
                    
                case SET_MANAGE_KEY:            //设置管理中心密钥
                    switch(pkg_num)
                    {
                        case 0x01:
                            recv_buff[0] = SET_MANAGE_KEY;
                            recv_buff[1] = 0;
                            recv_buff[2] = 34;
                            memcpy(recv_buff + 3,packetRX +3,15);
                            Back_subpackage(SET_MANAGE_KEY,pkg_num);
                            break;
                        
                        case 0x02:
                            memcpy(recv_buff + 18,packetRX +3,15);
                            Back_subpackage(SET_MANAGE_KEY,pkg_num);
                            break;
                        
                        case 0x03:
                            memcpy(recv_buff +33,packetRX +3,4);
                            data_length = recv_buff[2];
                            data_crc = comCalCRC16(recv_buff,data_length + 3);
                            check_crc = recv_buff[data_length +3]*256 + recv_buff[data_length +4];
                            if (data_crc==check_crc)
                            {
                                if (memcmp(recv_buff + 3,System_Config.ManageKey,16)==0)    
                                {
                                    Back_Massage_Minwen(SET_MANAGE_KEY,PRO_SUCCESS);
                                    memcpy(System_Config.ManageKey,recv_buff + 18,15);
                                    System_Config.sum = CRC_Sum((uint8 *)&System_Config,sizeof(System_Config)-1);
                                    Write_Flash((uint8 *)&System_Config,sizeof(System_Config));                                    
                                }
                                else
                                {
                                    Back_Massage_Minwen(SET_MANAGE_KEY,MKEY_ERROR);    
                                }
                            
                            }
                            else
                            {
                                Back_Massage_Minwen(SET_MANAGE_KEY,SECOND_CRC_ERROR);
                            }
                            break;
                        
                        default:
                            break;
                    }
                    break;
                        
                default:
                    break;
            }
        }
        else
        {
            Back_Massage_Minwen(cmd,FIRST_CRC_ERROR);
        }
        memset(packetRX,0x00,sizeof(packetRX));   
    }
}


/***********************************************
* 函数名：void SendBleCmd(void)
* 描述  ：处理蓝牙发送指令
***********************************************/
void SendBleCmd(void)
{
    switch(packetTXStep)
    {
        case BLE_IDLE:
            break;
        
        case Send_Lock_Info:
            Send_LockInfo();
            packetTXStep = BLE_IDLE;
            break;
        
        case Reply_OpenLock:
            packetTXStep = BLE_IDLE;
            Com_Array.Tx_State = RE_REQUEST;
            Back_Massage_Minwen(OPEN_LOCK_CMD,PRO_SUCCESS);
            break;
        
        default:
            break;     
    }
}

/***********************************************
* 函数名：uint16 comCalCRC16(uint8 *pucBuf, uint8 uwLength)
* 描述  ：CRC16校验
***********************************************/
uint16 comCalCRC16(uint8 *pucBuf, uint8 uwLength)
{
    uint16 uiCRCValue=0xffff;
    uint8 ucLoop;
    uint8 * pu8Buf = (uint8 *)pucBuf;
    while (uwLength--)
    {
        uiCRCValue ^= *pu8Buf++;
        for (ucLoop=0; ucLoop<8; ucLoop++)
        {
            if (uiCRCValue & 0x0001)
            {
                uiCRCValue >>= 1;
                uiCRCValue ^= CRC_POLY;
            }
            else
            {
                uiCRCValue >>= 1;
            }
        }
    }
    uiCRCValue ^= 0x0000;
    return uiCRCValue;
}




/* [] END OF FILE */

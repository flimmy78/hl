/*******************************************************************************
* File Name: Timer_clock.h
* Version 2.20
*
*  Description:
*   Provides the function and constant definitions for the clock component.
*
*  Note:
*
********************************************************************************
* Copyright 2008-2012, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions, 
* disclaimers, and limitations in the end user license agreement accompanying 
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_CLOCK_Timer_clock_H)
#define CY_CLOCK_Timer_clock_H

#include <cytypes.h>
#include <cyfitter.h>


/***************************************
*        Function Prototypes
***************************************/
#if defined CYREG_PERI_DIV_CMD

void Timer_clock_StartEx(uint32 alignClkDiv);
#define Timer_clock_Start() \
    Timer_clock_StartEx(Timer_clock__PA_DIV_ID)

#else

void Timer_clock_Start(void);

#endif/* CYREG_PERI_DIV_CMD */

void Timer_clock_Stop(void);

void Timer_clock_SetFractionalDividerRegister(uint16 clkDivider, uint8 clkFractional);

uint16 Timer_clock_GetDividerRegister(void);
uint8  Timer_clock_GetFractionalDividerRegister(void);

#define Timer_clock_Enable()                         Timer_clock_Start()
#define Timer_clock_Disable()                        Timer_clock_Stop()
#define Timer_clock_SetDividerRegister(clkDivider, reset)  \
    Timer_clock_SetFractionalDividerRegister((clkDivider), 0u)
#define Timer_clock_SetDivider(clkDivider)           Timer_clock_SetDividerRegister((clkDivider), 1u)
#define Timer_clock_SetDividerValue(clkDivider)      Timer_clock_SetDividerRegister((clkDivider) - 1u, 1u)


/***************************************
*             Registers
***************************************/
#if defined CYREG_PERI_DIV_CMD

#define Timer_clock_DIV_ID     Timer_clock__DIV_ID

#define Timer_clock_CMD_REG    (*(reg32 *)CYREG_PERI_DIV_CMD)
#define Timer_clock_CTRL_REG   (*(reg32 *)Timer_clock__CTRL_REGISTER)
#define Timer_clock_DIV_REG    (*(reg32 *)Timer_clock__DIV_REGISTER)

#define Timer_clock_CMD_DIV_SHIFT          (0u)
#define Timer_clock_CMD_PA_DIV_SHIFT       (8u)
#define Timer_clock_CMD_DISABLE_SHIFT      (30u)
#define Timer_clock_CMD_ENABLE_SHIFT       (31u)

#define Timer_clock_CMD_DISABLE_MASK       ((uint32)((uint32)1u << Timer_clock_CMD_DISABLE_SHIFT))
#define Timer_clock_CMD_ENABLE_MASK        ((uint32)((uint32)1u << Timer_clock_CMD_ENABLE_SHIFT))

#define Timer_clock_DIV_FRAC_MASK  (0x000000F8u)
#define Timer_clock_DIV_FRAC_SHIFT (3u)
#define Timer_clock_DIV_INT_MASK   (0xFFFFFF00u)
#define Timer_clock_DIV_INT_SHIFT  (8u)

#else 

#define Timer_clock_DIV_REG        (*(reg32 *)Timer_clock__REGISTER)
#define Timer_clock_ENABLE_REG     Timer_clock_DIV_REG
#define Timer_clock_DIV_FRAC_MASK  Timer_clock__FRAC_MASK
#define Timer_clock_DIV_FRAC_SHIFT (16u)
#define Timer_clock_DIV_INT_MASK   Timer_clock__DIVIDER_MASK
#define Timer_clock_DIV_INT_SHIFT  (0u)

#endif/* CYREG_PERI_DIV_CMD */

#endif /* !defined(CY_CLOCK_Timer_clock_H) */

/* [] END OF FILE */

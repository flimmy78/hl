#include "main.h"
int main()
{
    CYBLE_API_RESULT_T      bleApiResult;
   
    UART_Start();  

    bleApiResult = CyBle_Start(AppCallBack); 
    if(bleApiResult == CYBLE_ERROR_OK)
    {
        Conn_LED_Write(1);
    }
    else
    {
       
    }
    CyGlobalIntEnable;
    UART_UartPutString("System Begin Work\r\n");
    CyBle_ProcessEvents();
    
   
    while(1)
    {              
       
      
         /*******************************************************************
        *  Process all pending BLE events in the stack
        *******************************************************************/       
        HandleBleProcessing();//BLE连接与断开
        CyBle_ProcessEvents();
       
        ReceiveBleCmd();     
       
    }
}
/* END OF FILE */
